
import React, { useState, useCallback, useEffect } from 'react';
import Header from './components/Header.tsx';
import SearchForm from './components/SearchForm.tsx';
import LeadCard from './components/LeadCard.tsx';
import Auth from './components/Auth.tsx';
import Settings from './components/Settings.tsx';
import DashboardHome from './components/DashboardHome.tsx';
import Pipeline from './components/Pipeline.tsx';
import Integrations from './components/Integrations.tsx';
import OutreachModal from './components/OutreachModal.tsx';
import LandingPage from './components/LandingPage.tsx';
import Onboarding from './components/Onboarding.tsx';
import Billing from './components/Billing.tsx';
import { SearchParams, Lead, ViewType, UserProfile, LeadStatus, Integration } from './types.ts';
import { searchLeads } from './services/geminiService.ts';
import { supabase, isSupabaseConfigured } from './lib/supabase.ts';

const DEFAULT_INTEGRATIONS: Integration[] = [
  // Email & Outreach
  { id: 'instantly', name: 'Instantly.ai', type: 'email', connected: false, icon: '🚀', description: 'Scale cold outreach with automated sequences.', authUrl: 'https://app.instantly.ai/', color: 'bg-blue-600', isShared: true },
  { id: 'lemlist', name: 'Lemlist', type: 'email', connected: false, icon: '🍋', description: 'Personalized cold email software for high response rates.', authUrl: 'https://app.lemlist.com/', color: 'bg-yellow-500', isShared: true },
  { id: 'apollo', name: 'Apollo.io', type: 'email', connected: false, icon: '🛰️', description: 'Find, contact, and close your ideal buyers.', authUrl: 'https://app.apollo.io/', color: 'bg-indigo-700', isShared: true },
  { id: 'woodpecker', name: 'Woodpecker', type: 'email', connected: false, icon: '🐦', description: 'Cold email automation for sales professionals.', authUrl: 'https://app.woodpecker.co/', color: 'bg-red-500', isShared: true },
  { id: 'hunter', name: 'Hunter.io', type: 'email', connected: false, icon: '🏹', description: 'Find professional email addresses in seconds.', authUrl: 'https://hunter.io/', color: 'bg-orange-600', isShared: true },
  { id: 'sendgrid', name: 'SendGrid', type: 'email', connected: false, icon: '📧', description: 'Deliver high-volume transactional outreach.', authUrl: 'https://app.sendgrid.com/', color: 'bg-indigo-500', isShared: true },
  { id: 'mailchimp', name: 'Mailchimp', type: 'email', connected: false, icon: '🐵', description: 'Automate marketing emails and landing pages.', authUrl: 'https://admin.mailchimp.com/', color: 'bg-yellow-400', isShared: true },
  { id: 'mailerlite', name: 'MailerLite', type: 'email', connected: false, icon: '💌', description: 'Simple and effective email marketing for business.', authUrl: 'https://app.mailerlite.com/', color: 'bg-emerald-400', isShared: true },

  // CRM & Lead Management
  { id: 'hubspot', name: 'HubSpot', type: 'crm', connected: false, icon: '🧡', description: 'Inbound marketing, sales, and service software.', authUrl: 'https://app.hubspot.com/', color: 'bg-orange-500', isShared: true },
  { id: 'salesforce', name: 'Salesforce', type: 'crm', connected: false, icon: '☁️', description: 'The worlds #1 customer relationship management.', authUrl: 'https://login.salesforce.com/', color: 'bg-sky-500', isShared: true },
  { id: 'pipedrive', name: 'Pipedrive', type: 'crm', connected: false, icon: '📉', description: 'Sales pipeline and CRM software for small teams.', authUrl: 'https://app.pipedrive.com/', color: 'bg-emerald-500', isShared: true },
  { id: 'zoho', name: 'Zoho CRM', type: 'crm', connected: false, icon: '🦓', description: 'A complete CRM solution for growing businesses.', authUrl: 'https://crm.zoho.com/', color: 'bg-red-600', isShared: true },
  { id: 'monday', name: 'Monday.com', type: 'crm', connected: false, icon: '📅', description: 'Work OS to manage all your sales pipelines.', authUrl: 'https://monday.com/login', color: 'bg-pink-500', isShared: true },
  { id: 'airtable', name: 'Airtable', type: 'crm', connected: false, icon: '☁️', description: 'Low-code platform for building lead databases.', authUrl: 'https://airtable.com/login', color: 'bg-blue-400', isShared: true },
  { id: 'notion', name: 'Notion', type: 'crm', connected: false, icon: '📝', description: 'The all-in-one workspace for notes and leads.', authUrl: 'https://notion.so/login', color: 'bg-slate-900', isShared: true },
  { id: 'clickup', name: 'ClickUp', type: 'crm', connected: false, icon: '✅', description: 'One app to replace them all for project management.', authUrl: 'https://app.clickup.com/login', color: 'bg-purple-600', isShared: true },

  // Workflow & Comms
  { id: 'zapier', name: 'Zapier', type: 'workflow', connected: false, icon: '⚡', description: 'Connect LeadLive to 5,000+ other apps.', authUrl: 'https://zapier.com/app/login', color: 'bg-orange-400', isShared: true },
  { id: 'slack', name: 'Slack', type: 'workflow', connected: false, icon: '💬', description: 'Get instant lead notifications in your channels.', authUrl: 'https://slack.com/signin', color: 'bg-indigo-400', isShared: true },
  { id: 'make', name: 'Make.com', type: 'workflow', connected: false, icon: '⚙️', description: 'Design complex automated lead workflows visually.', authUrl: 'https://www.make.com/en/login', color: 'bg-indigo-600', isShared: true },
  { id: 'trello', name: 'Trello', type: 'workflow', connected: false, icon: '📋', description: 'Manage your leads as visual boards and cards.', authUrl: 'https://trello.com/login', color: 'bg-blue-500', isShared: true }
];

const App: React.FC = () => {
  const [session, setSession] = useState<any>(null);
  const [authChecking, setAuthChecking] = useState(isSupabaseConfigured);
  const [activeView, setActiveView] = useState<ViewType>('home');
  const [loading, setLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [lastSearchParams, setLastSearchParams] = useState<SearchParams | null>(null);
  const [results, setResults] = useState<{ leads: Lead[]; summary: string; sources: any[] } | null>(null);
  const [savedLeads, setSavedLeads] = useState<Lead[]>([]);
  const [integrations, setIntegrations] = useState<Integration[]>(DEFAULT_INTEGRATIONS);
  const [outreachLead, setOutreachLead] = useState<Lead | null>(null);
  const [showSearchForm, setShowSearchForm] = useState(true);
  const [showAuth, setShowAuth] = useState(false);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [notification, setNotification] = useState<string | null>(null);

  useEffect(() => {
    const storedSaved = localStorage.getItem('livelead_saved_leads');
    if (storedSaved) setSavedLeads(JSON.parse(storedSaved));
    
    const storedIntegrations = localStorage.getItem('livelead_integrations');
    if (storedIntegrations) setIntegrations(JSON.parse(storedIntegrations));

    const storedProfileRaw = localStorage.getItem('livelead_profile');
    if (storedProfileRaw) {
      let storedProfile: UserProfile = JSON.parse(storedProfileRaw);
      const today = new Date().toDateString();
      if (storedProfile.lastScanReset !== today) {
        storedProfile.scansRemaining = storedProfile.plan === 'elite' ? 9999 : 3;
        storedProfile.lastScanReset = today;
      }
      setProfile(storedProfile);
    }

    if (!isSupabaseConfigured) {
      setAuthChecking(false);
      return;
    }

    supabase?.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setAuthChecking(false);
    });

    const { data: { subscription } } = supabase!.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    localStorage.setItem('livelead_saved_leads', JSON.stringify(savedLeads));
  }, [savedLeads]);

  useEffect(() => {
    localStorage.setItem('livelead_integrations', JSON.stringify(integrations));
  }, [integrations]);

  useEffect(() => {
    if (profile) localStorage.setItem('livelead_profile', JSON.stringify(profile));
  }, [profile]);

  const handleOnboardingComplete = (newProfile: UserProfile) => {
    const enrichedProfile: UserProfile = {
      ...newProfile,
      plan: 'free',
      scansRemaining: 3,
      totalScansPerformed: 0,
      lastScanReset: new Date().toDateString(),
      teamId: Math.random().toString(), // Mock team ID
      role: 'owner'
    };
    setProfile(enrichedProfile);
    setNotification("Deployment Successful. Workspace Initialized.");
    setTimeout(() => setNotification(null), 5000);
    
    const initialParams: SearchParams = {
      niche: enrichedProfile.niche,
      experienceLevel: enrichedProfile.experienceLevel,
      budgetMin: 1000,
      platforms: ['Upwork', 'LinkedIn', 'Freelancer'],
      jobType: 'Freelance',
      remoteOption: 'Remote',
      keywords: enrichedProfile.interests.join(', '),
      userEmail: enrichedProfile.email,
      autoNotify: true,
      notificationFrequency: 'daily'
    };
    setLastSearchParams(initialParams);
  };

  const checkPlanLimit = (): boolean => {
    if (!profile) return false;
    if (profile.plan === 'elite') return true;
    if (profile.scansRemaining <= 0) {
      setNotification("Daily limit reached. Please upgrade to Elite.");
      setActiveView('billing');
      setTimeout(() => setNotification(null), 5000);
      return false;
    }
    return true;
  };

  const decrementScanUsage = () => {
    if (!profile) return;
    setProfile(prev => prev ? {
      ...prev,
      scansRemaining: prev.plan === 'elite' ? prev.scansRemaining : Math.max(0, prev.scansRemaining - 1),
      totalScansPerformed: prev.totalScansPerformed + 1
    } : null);
  };

  const handleSearch = useCallback(async (params: SearchParams) => {
    if (!checkPlanLimit()) return;

    setLoading(true);
    setResults(null);
    setShowSearchForm(false);
    setLastSearchParams(params);
    try {
      const data = await searchLeads({ ...params, userBio: profile?.bio });
      setResults(data);
      decrementScanUsage();
    } catch (err: any) {
      console.error(err);
      setNotification("Search failed. Check connection.");
      setShowSearchForm(true);
      setTimeout(() => setNotification(null), 3000);
    } finally {
      setLoading(false);
    }
  }, [profile, profile?.bio]);

  const handleLoadMore = useCallback(async () => {
    if (!lastSearchParams || !results) return;
    if (!checkPlanLimit()) return;

    setLoadingMore(true);
    try {
      const data = await searchLeads({ ...lastSearchParams, userBio: profile?.bio }, results.leads);
      setResults(prev => prev ? {
        ...prev,
        leads: [...prev.leads, ...data.leads],
        summary: data.summary 
      } : null);
      decrementScanUsage();
      setNotification("Expanded scan results.");
    } catch (err: any) {
      console.error(err);
      setNotification("Failed to fetch more.");
    } finally {
      setLoadingMore(false);
      setTimeout(() => setNotification(null), 3000);
    }
  }, [lastSearchParams, results, profile, profile?.bio]);

  const handleUpgradeToElite = useCallback(() => {
    if (profile) {
      setProfile(prev => prev ? {
        ...prev,
        plan: 'elite',
        scansRemaining: 9999
      } : null);
      setNotification("Elite Access Activated!");
      setTimeout(() => setNotification(null), 5000);
    }
  }, [profile]);

  const toggleSaveLead = (lead: Lead) => {
    setSavedLeads(prev => {
      const isSaved = prev.some(l => l.id === lead.id);
      if (isSaved) return prev.filter(l => l.id !== lead.id);
      return [...prev, { ...lead, status: 'scouted', assignedTo: profile?.email }];
    });
    const isSaved = savedLeads.some(l => l.id === lead.id);
    setNotification(isSaved ? "Lead discarded from Team" : "Lead synced to Team Pipeline");
    setTimeout(() => setNotification(null), 3000);
  };

  const handleStatusChange = (id: string, status: LeadStatus) => {
    setSavedLeads(prev => prev.map(l => l.id === id ? { ...l, status } : l));
  };

  const handleIntegrationAction = (id: string, action: 'redirect' | 'toggle') => {
    const item = integrations.find(i => i.id === id);
    if (!item) return;

    if (action === 'redirect') {
      window.open(item.authUrl, '_blank');
      setNotification(`Opening ${item.name}...`);
    } else if (action === 'toggle') {
      setIntegrations(prev => prev.map(i => i.id === id ? { ...i, connected: !i.connected } : i));
      setNotification(item.connected ? `${item.name} Disconnected` : `${item.name} Connected for Team`);
    }
    
    setTimeout(() => setNotification(null), 4000);
  };

  const handleSendOutreach = (leadId: string, content: string, softwareId: string) => {
    const software = integrations.find(i => i.id === softwareId);
    setSavedLeads(prev => prev.map(l => l.id === leadId ? { ...l, status: 'applied', lastContacted: new Date().toISOString() } : l));
    setNotification(`Team outreach via ${software?.name} complete.`);
    setOutreachLead(null);
    setTimeout(() => setNotification(null), 4000);
  };

  const handleCrmSync = (lead: Lead) => {
    if (profile?.plan === 'free') {
      setNotification("CRM Sync is an Elite feature.");
      setActiveView('billing');
      setTimeout(() => setNotification(null), 5000);
      return;
    }
    const crm = integrations.find(i => i.type === 'crm' && i.connected);
    if (!crm) {
      setNotification("Connect a CRM first.");
      setTimeout(() => setNotification(null), 3000);
      return;
    }
    setResults(prev => prev ? {
      ...prev,
      leads: prev.leads.map(l => l.id === lead.id ? { ...l, syncedToCrm: true } : l)
    } : null);
    setSavedLeads(prev => prev.map(l => l.id === lead.id ? { ...l, syncedToCrm: true } : l));
    setNotification(`Synced to Team ${crm.name}.`);
    setTimeout(() => setNotification(null), 3000);
  };

  if (authChecking) return <div className="min-h-screen bg-slate-50 flex items-center justify-center"><div className="w-10 h-10 border-4 border-indigo-600/20 border-t-indigo-600 rounded-full animate-spin"></div></div>;

  const savedIds = new Set<string>(savedLeads.map(l => l.id));
  const connectedEmails = integrations.filter(i => i.type === 'email' && i.connected);
  const hasConnectedCrm = integrations.some(i => i.type === 'crm' && i.connected);

  if (!session) {
    return showAuth ? <Auth onBack={() => setShowAuth(false)} /> : <LandingPage onGetStarted={() => setShowAuth(true)} />;
  }

  if (!profile || !profile.hasCompletedOnboarding) {
    return <Onboarding userEmail={session.user.email} onComplete={handleOnboardingComplete} />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#fcfcfd] overflow-x-hidden">
      <Header 
        session={session} 
        profile={profile}
        onNavigate={(view) => { setActiveView(view); if (view === 'scout') setShowSearchForm(true); }} 
        activeView={activeView} 
      />
      
      {notification && (
        <div className="fixed top-20 right-4 md:right-6 z-[110] animate-in slide-in-from-right-4 fade-in">
          <div className="bg-slate-900 text-white px-5 md:px-6 py-3 md:py-4 rounded-xl md:rounded-2xl shadow-2xl flex items-center gap-3 border border-slate-800">
             <div className="w-2 h-2 rounded-full bg-indigo-500 animate-ping"></div>
            <span className="font-bold text-[10px] uppercase tracking-widest">{notification}</span>
          </div>
        </div>
      )}

      {outreachLead && (
        <OutreachModal 
          lead={outreachLead} 
          onClose={() => setOutreachLead(null)} 
          onSend={handleSendOutreach}
          connectedEmails={connectedEmails}
        />
      )}

      <main className="flex-grow w-full">
        <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-6 md:py-10">
          <div className="flex flex-col lg:flex-row gap-8 lg:gap-10">
            {/* Sidebar Navigation */}
            <aside className="w-full lg:w-64 xl:w-72 shrink-0">
              <div className="lg:sticky lg:top-24">
                <div className="bg-white border border-slate-200 rounded-3xl p-4 md:p-6 shadow-xl shadow-slate-200/50">
                  <nav className="flex flex-row lg:flex-col gap-1.5 overflow-x-auto lg:overflow-x-visible pb-2 lg:pb-0 no-scrollbar">
                    {[
                      { id: 'home', label: 'Overview' },
                      { id: 'scout', label: 'AI Scout' },
                      { id: 'pipeline', label: 'Shared Pipeline' },
                      { id: 'integrations', label: 'Team Stack' },
                      { id: 'billing', label: 'Elite Access' },
                      { id: 'settings', label: 'Workspace' }
                    ].map(item => (
                      <button 
                        key={item.id}
                        onClick={() => { 
                          setActiveView(item.id as ViewType); 
                          if (item.id === 'scout') setShowSearchForm(true); 
                        }} 
                        className={`flex items-center gap-4 px-4 py-3 rounded-xl font-black text-[9px] md:text-[10px] uppercase tracking-widest transition-all whitespace-nowrap lg:whitespace-normal flex-grow lg:flex-grow-0 ${
                          activeView === item.id 
                            ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' 
                            : 'text-slate-400 hover:bg-slate-50'
                        }`}
                      >
                        {item.label}
                      </button>
                    ))}
                  </nav>
                </div>
              </div>
            </aside>

            {/* Content Area */}
            <section className="flex-grow min-w-0">
              {activeView === 'home' && <DashboardHome profile={profile} leadsFound={results?.leads.length || 0} savedCount={savedLeads.length} onNavigate={(v) => { setActiveView(v); if(v==='scout') setShowSearchForm(true); }} />}
              
              {activeView === 'scout' && (
                <div className="space-y-6 md:space-y-8 animate-in fade-in duration-500">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h2 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight">AI Scouting Unit</h2>
                      <p className="text-slate-500 text-xs md:text-sm font-medium">Monitoring shared targeting for {profile.industry}.</p>
                    </div>
                    {!showSearchForm && (
                      <button onClick={() => setShowSearchForm(true)} className="bg-white border border-slate-200 px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-slate-50 transition-all">Adjust Target</button>
                    )}
                  </div>
                  {showSearchForm && <div className="max-w-4xl"><SearchForm initialParams={lastSearchParams} onSearch={handleSearch} isLoading={loading} /></div>}
                  {loading && (
                    <div className="flex flex-col items-center justify-center py-20 md:py-32 bg-white rounded-[2rem] shadow-xl border border-slate-100">
                      <div className="w-12 h-12 md:w-16 md:h-16 border-4 border-slate-50 border-t-indigo-600 rounded-full animate-spin"></div>
                      <p className="mt-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">Team Scout Deployed...</p>
                    </div>
                  )}
                  {!loading && results && (
                    <LeadCard 
                      leads={results.leads} 
                      summary={results.summary} 
                      savedIds={savedIds} 
                      onToggleSave={toggleSaveLead} 
                      onSyncCrm={handleCrmSync}
                      hasConnectedCrm={hasConnectedCrm}
                      onLoadMore={handleLoadMore}
                      isLoadingMore={loadingMore}
                    />
                  )}
                </div>
              )}

              {activeView === 'pipeline' && (
                <div className="space-y-6 md:space-y-8 h-full">
                  <div>
                    <h2 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight">Team Revenue Funnel</h2>
                    <p className="text-slate-500 text-xs md:text-sm font-medium">Shared visibility across all active opportunities.</p>
                  </div>
                  <Pipeline 
                    leads={savedLeads} 
                    onStatusChange={handleStatusChange} 
                    onViewLead={(l) => { setOutreachLead(l); }} 
                    onSyncCrm={(id) => {
                      const lead = savedLeads.find(l => l.id === id);
                      if (lead) handleCrmSync(lead);
                    }} 
                  />
                </div>
              )}

              {activeView === 'integrations' && <Integrations integrations={integrations} onAction={handleIntegrationAction} />}
              {activeView === 'billing' && <Billing profile={profile} onUpgrade={handleUpgradeToElite} />}
              {activeView === 'settings' && <Settings profile={profile} onUpdate={setProfile} />}
            </section>
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
