
import { GoogleGenAI, Type } from "@google/genai";
import { SearchParams, Lead } from "../types.ts";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const searchLeads = async (
  params: SearchParams, 
  excludeLeads: Lead[] = []
): Promise<{ leads: Lead[]; summary: string; sources: any[] }> => {
  const currentDate = new Date().toLocaleDateString('en-US', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });

  const excludeTitles = excludeLeads.map(l => l.title).slice(-10).join(', ');
  
  const prompt = `
    URGENT: GLOBAL LEAD DOMINATION PROTOCOL.
    Current Date: ${currentDate}.
    User Profile Niche: ${params.niche}.
    User Experience: ${params.experienceLevel}.
    User Bio: ${params.userBio || "Not provided"}.
    
    TASK: Find 6-8 PREMIUM ACTIVE job opportunities.
    STRICT EXCLUSION: [${excludeTitles}].
    
    FOR EACH LEAD, YOU MUST PERFORM DEEP SEARCH TO FIND:
    1. matchScore: 0-100 integer based on how well the job fits the User's Bio/Niche.
    2. matchReason: One sentence explaining why they are a perfect match.
    
    3. proposalTemplate: A hyper-tailored 200-word winning proposal. 
       - It MUST mention the [Company Name] and [Job Title] specifically.
       - It MUST reference specific skills from the job description and tie them to the "User Bio" provided.
       - It should sound human, authoritative, and focused on solving the client's problem.
       - Include a specific "First Step" or "Call to Action" tailored to this niche.
       - DO NOT use generic placeholders like [Name]; write it as if you are sending it now.

    4. outreachTemplate: A short, high-impact LinkedIn/Cold Email message (max 100 words).
       - Focus on a specific observation about their company or the role.
       - Tightly integrated with the "User Bio".

    5. followUpSequence: { step2: "3-day follow-up", step3: "7-day check-in" }.
    6. competitorIntel: Briefly describe what competitors are likely bidding and how the user can stand out.
    7. clientRating: A number between 0 and 5 representing client reputation.
    8. clientReviewsCount: Total number of previous reviews for this client.
    9. duration: A human-readable estimate (e.g., "3 months", "One-off task", "6+ months").
    10. durationWeeks: A numeric estimate of duration in weeks (use 1 for small tasks, 52 for long-term/ongoing).
    
    CORE REQUIREMENT - CONTACT INTEL:
    11. email: Find a direct email for the company or hiring manager if possible.
    12. phone: Find a contact number if available on public records.
    13. socialLinks: Find LinkedIn, Twitter, or Instagram profiles for the company or hiring manager.
    14. hiringContactName: The name of the person likely in charge of this hiring.

    ANTI-404 RULES:
    Only use high-authority job boards and direct company career pages. Verified links only.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            leads: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  title: { type: Type.STRING },
                  company: { type: Type.STRING },
                  description: { type: Type.STRING },
                  platform: { type: Type.STRING },
                  budget: { type: Type.STRING },
                  postedAt: { type: Type.STRING },
                  url: { type: Type.STRING },
                  mirrorSearchUrl: { type: Type.STRING },
                  freshnessScore: { type: Type.NUMBER },
                  matchScore: { type: Type.NUMBER },
                  matchReason: { type: Type.STRING },
                  proposalTemplate: { type: Type.STRING },
                  outreachTemplate: { type: Type.STRING },
                  followUpSequence: {
                    type: Type.OBJECT,
                    properties: {
                      step2: { type: Type.STRING },
                      step3: { type: Type.STRING }
                    }
                  },
                  competitorIntel: { type: Type.STRING },
                  skills: { type: Type.ARRAY, items: { type: Type.STRING } },
                  clientRating: { type: Type.NUMBER },
                  clientReviewsCount: { type: Type.NUMBER },
                  duration: { type: Type.STRING },
                  durationWeeks: { type: Type.NUMBER },
                  email: { type: Type.STRING },
                  phone: { type: Type.STRING },
                  hiringContactName: { type: Type.STRING },
                  socialLinks: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        platform: { type: Type.STRING },
                        url: { type: Type.STRING }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      },
    });

    const text = response.text || '{}';
    const result = JSON.parse(text);
    
    const leads = (result.leads || []).map((l: any) => ({
      ...l,
      status: 'scouted'
    }));

    return {
      leads: leads,
      summary: result.summary || "Live scan complete.",
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  } catch (error) {
    console.error("Link integrity scan failed:", error);
    throw error;
  }
};

export const fetchMarketNews = async (company: string, niche: string): Promise<{ text: string; links: { title: string; uri: string }[] }> => {
  try {
    const prompt = `Find the latest news, trending topics, and corporate updates for "${company}" or the "${niche}" industry in general. Provide a concise bulleted summary of the most relevant news from the last 30 days. Focus on things that would help a freelancer or consultant understand the current state of the client or market.`;
    
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const text = response.text || "No recent news found.";
    
    // Extract sources as per rules
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const links = groundingChunks
      .filter((chunk: any) => chunk.web && chunk.web.uri)
      .map((chunk: any) => ({
        title: chunk.web.title || "Source",
        uri: chunk.web.uri
      }));

    return { text, links };
  } catch (error) {
    console.error("Market news fetch failed:", error);
    return { text: "Unable to retrieve news at this time.", links: [] };
  }
};
