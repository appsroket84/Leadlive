
import React from 'react';
import { Lead, LeadStatus } from '../types.ts';

interface PipelineProps {
  leads: Lead[];
  onStatusChange: (id: string, status: LeadStatus) => void;
  onViewLead: (lead: Lead) => void;
  onSyncCrm: (id: string) => void;
}

const COLUMNS: { id: LeadStatus; label: string; color: string }[] = [
  { id: 'scouted', label: 'Scouted', color: 'bg-slate-100 text-slate-600' },
  { id: 'applied', label: 'Applied', color: 'bg-indigo-100 text-indigo-600' },
  { id: 'interviewing', label: 'Interviewing', color: 'bg-amber-100 text-amber-600' },
  { id: 'won', label: 'Won', color: 'bg-emerald-100 text-emerald-600' }
];

const Pipeline: React.FC<PipelineProps> = ({ leads, onStatusChange, onViewLead, onSyncCrm }) => {
  return (
    <div className="flex flex-row gap-4 md:gap-6 h-full overflow-x-auto pb-10 -mx-4 px-4 snap-x">
      {COLUMNS.map((col) => {
        const columnLeads = leads.filter(l => l.status === col.id);
        
        return (
          <div key={col.id} className="flex-shrink-0 w-[280px] md:w-80 flex flex-col gap-4 snap-start">
            <div className="flex items-center justify-between px-2">
              <h3 className="text-[9px] md:text-xs font-black uppercase tracking-[0.2em] text-slate-400">
                {col.label} <span className="ml-2 bg-slate-100 px-2 py-0.5 rounded-full text-slate-400 font-bold">{columnLeads.length}</span>
              </h3>
            </div>
            
            <div className="flex-grow space-y-4 min-h-[400px] md:min-h-[600px] p-3 bg-slate-50/50 rounded-[1.5rem] md:rounded-[2rem] border border-slate-100 border-dashed">
              {columnLeads.length === 0 ? (
                <div className="flex items-center justify-center h-20 text-[9px] font-black text-slate-300 uppercase tracking-widest">
                  Funnel Empty
                </div>
              ) : columnLeads.map((lead) => (
                <div 
                  key={lead.id} 
                  className="bg-white p-4 md:p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all group relative animate-in fade-in duration-300"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[8px] font-black text-slate-400 uppercase tracking-tighter">{lead.platform}</span>
                    <div className="flex gap-1.5">
                       {lead.syncedToCrm && <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" title="Synced to Team CRM"></div>}
                       <div className="w-4 h-4 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center" title="Assigned Member">
                          <span className="text-[6px] font-black text-slate-400">SD</span>
                       </div>
                    </div>
                  </div>
                  <h4 className="text-xs font-black text-slate-900 mb-1 line-clamp-2 leading-tight group-hover:text-indigo-600 transition-colors">
                    {lead.title}
                  </h4>
                  <p className="text-[9px] font-bold text-slate-400 mb-3">{lead.company}</p>
                  
                  <div className="flex flex-col gap-1.5 mb-3">
                    <button 
                      onClick={() => onViewLead(lead)}
                      className="w-full py-2 bg-slate-900 text-white rounded-lg text-[8px] font-black uppercase tracking-widest hover:bg-indigo-600 transition-colors"
                    >
                      Team Outreach
                    </button>
                    <button 
                      onClick={() => onSyncCrm(lead.id)}
                      disabled={lead.syncedToCrm}
                      className={`w-full py-2 rounded-lg text-[8px] font-black uppercase tracking-widest border transition-colors ${lead.syncedToCrm ? 'bg-slate-50 border-slate-100 text-slate-300' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}`}
                    >
                      {lead.syncedToCrm ? 'In CRM' : 'Push CRM'}
                    </button>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                    <div className="flex gap-1 overflow-x-auto no-scrollbar max-w-[120px]">
                      {COLUMNS.filter(c => c.id !== lead.status).map(target => (
                        <button
                          key={target.id}
                          onClick={() => onStatusChange(lead.id, target.id)}
                          className="flex-shrink-0 px-1.5 py-1 rounded border border-slate-100 hover:bg-indigo-50 hover:text-indigo-600 text-[7px] font-black text-slate-400 uppercase"
                          title={`Move to ${target.label}`}
                        >
                          → {target.label.charAt(0)}
                        </button>
                      ))}
                    </div>
                    <span className="text-[9px] font-black text-indigo-600 truncate ml-2">{lead.budget || '$--'}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default Pipeline;
