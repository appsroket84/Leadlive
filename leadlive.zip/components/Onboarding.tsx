
import React, { useState } from 'react';
import { UserProfile } from '../types.ts';

interface OnboardingProps {
  onComplete: (profile: UserProfile) => void;
  userEmail: string;
}

const INDUSTRIES = [
  'Tech & Software', 'Marketing & Advertising', 'E-commerce', 
  'Health & Wellness', 'Financial Services', 'Real Estate', 
  'Education', 'Creative Arts', 'Legal', 'Consulting'
];

const INTERESTS = [
  'High-ticket Sales', 'Short-term Gigs', 'Retainer Contracts', 
  'Enterprise Clients', 'Startups', 'Non-profits', 'Remote Only',
  'Global Markets', 'Fortune 500', 'Direct Outreach'
];

export default function Onboarding({ onComplete, userEmail }: OnboardingProps) {
  const [step, setStep] = useState(1);
  const [profile, setProfile] = useState<Partial<UserProfile>>({
    fullName: '',
    email: userEmail,
    phone: '',
    industry: 'Tech & Software',
    niche: '',
    experienceLevel: 'Expert',
    bio: '',
    interests: [],
    hasCompletedOnboarding: false
  });

  const nextStep = () => setStep(s => s + 1);
  const prevStep = () => setStep(s => s - 1);

  const toggleInterest = (interest: string) => {
    setProfile(p => ({
      ...p,
      interests: p.interests?.includes(interest)
        ? p.interests.filter(i => i !== interest)
        : [...(p.interests || []), interest]
    }));
  };

  const handleFinish = () => {
    onComplete({ ...profile, hasCompletedOnboarding: true } as UserProfile);
  };

  return (
    <div className="min-h-screen bg-[#fcfcfd] flex items-center justify-center px-4 py-20 auth-gradient">
      <div className="max-w-xl w-full bg-white rounded-[3rem] shadow-2xl p-10 md:p-14 border border-slate-100 relative overflow-hidden">
        {/* Progress Bar */}
        <div className="absolute top-0 left-0 w-full h-2 bg-slate-50">
          <div 
            className="h-full bg-indigo-600 transition-all duration-700" 
            style={{ width: `${(step / 3) * 100}%` }}
          ></div>
        </div>

        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
          {step === 1 && (
            <div className="space-y-8">
              <div className="text-center">
                <h2 className="text-4xl font-black text-slate-900 tracking-tight mb-2">Build Your Identity</h2>
                <p className="text-slate-500 font-medium">Let's start with the basics of your professional business.</p>
              </div>
              <div className="space-y-6">
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block ml-1">Full Business Name</label>
                  <input 
                    type="text" 
                    value={profile.fullName}
                    onChange={e => setProfile({...profile, fullName: e.target.value})}
                    placeholder="e.g. Acme Consulting"
                    className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-600 outline-none transition-all font-bold"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block ml-1">Direct Contact Phone</label>
                  <input 
                    type="tel" 
                    value={profile.phone}
                    onChange={e => setProfile({...profile, phone: e.target.value})}
                    placeholder="+1 (555) 000-0000"
                    className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-600 outline-none transition-all font-bold"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block ml-1">Experience Level</label>
                  <div className="flex gap-3">
                    {['Entry', 'Intermediate', 'Expert'].map(lvl => (
                      <button
                        key={lvl}
                        onClick={() => setProfile({...profile, experienceLevel: lvl})}
                        className={`flex-1 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest border transition-all ${
                          profile.experienceLevel === lvl ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg' : 'bg-white text-slate-400 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        {lvl}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              <button 
                onClick={nextStep}
                disabled={!profile.fullName || !profile.phone}
                className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black text-sm uppercase tracking-[0.2em] hover:bg-indigo-600 transition-all shadow-xl disabled:opacity-50"
              >
                Continue Deployment
              </button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-8">
              <div className="text-center">
                <h2 className="text-4xl font-black text-slate-900 tracking-tight mb-2">Market Expertise</h2>
                <p className="text-slate-500 font-medium">Which industries and niches do you dominate?</p>
              </div>
              <div className="space-y-6">
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 block ml-1">Primary Industry</label>
                  <div className="grid grid-cols-2 gap-2">
                    {INDUSTRIES.map(ind => (
                      <button
                        key={ind}
                        onClick={() => setProfile({...profile, industry: ind})}
                        className={`py-3 px-4 rounded-xl text-[10px] font-bold text-left transition-all border ${
                          profile.industry === ind ? 'bg-indigo-50 border-indigo-600 text-indigo-700 shadow-sm' : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        {ind}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block ml-1">Specialized Niche</label>
                  <input 
                    type="text" 
                    value={profile.niche}
                    onChange={e => setProfile({...profile, niche: e.target.value})}
                    placeholder="e.g. React Native SaaS, B2B SEO"
                    className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-600 outline-none transition-all font-bold"
                  />
                </div>
              </div>
              <div className="flex gap-4">
                <button onClick={prevStep} className="w-1/3 py-5 text-[10px] font-black uppercase text-slate-400 hover:text-slate-600">Go Back</button>
                <button 
                  onClick={nextStep}
                  disabled={!profile.niche}
                  className="flex-grow bg-slate-900 text-white py-5 rounded-2xl font-black text-sm uppercase tracking-[0.2em] hover:bg-indigo-600 transition-all shadow-xl disabled:opacity-50"
                >
                  Configure Scouts
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-8">
              <div className="text-center">
                <h2 className="text-4xl font-black text-slate-900 tracking-tight mb-2">Interests & Targeting</h2>
                <p className="text-slate-500 font-medium">Tell our AI exactly what you're looking for.</p>
              </div>
              <div className="space-y-6">
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 block ml-1">Select All That Apply</label>
                  <div className="flex flex-wrap gap-2">
                    {INTERESTS.map(int => (
                      <button
                        key={int}
                        onClick={() => toggleInterest(int)}
                        className={`py-2.5 px-5 rounded-full text-[10px] font-black uppercase tracking-widest border transition-all ${
                          profile.interests?.includes(int) ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg' : 'bg-white text-slate-400 border-slate-200 hover:border-indigo-300'
                        }`}
                      >
                        {int}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block ml-1">Personal Mission / Bio</label>
                  <textarea 
                    value={profile.bio}
                    onChange={e => setProfile({...profile, bio: e.target.value})}
                    placeholder="I help companies scale their infrastructure using..."
                    className="w-full px-5 py-5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-600 outline-none transition-all font-medium h-32 resize-none leading-relaxed"
                  />
                </div>
              </div>
              <div className="flex gap-4">
                <button onClick={prevStep} className="w-1/3 py-5 text-[10px] font-black uppercase text-slate-400 hover:text-slate-600">Go Back</button>
                <button 
                  onClick={handleFinish}
                  disabled={!profile.bio || profile.interests!.length === 0}
                  className="flex-grow bg-slate-900 text-white py-5 rounded-2xl font-black text-sm uppercase tracking-[0.2em] hover:bg-indigo-600 transition-all shadow-xl disabled:opacity-50"
                >
                  Complete Onboarding
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
