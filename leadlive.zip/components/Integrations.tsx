
import React, { useState } from 'react';
import { Integration } from '../types.ts';

interface IntegrationsProps {
  integrations: Integration[];
  onAction: (id: string, action: 'redirect' | 'toggle') => void;
}

const Integrations: React.FC<IntegrationsProps> = ({ integrations, onAction }) => {
  const [filter, setFilter] = useState<'all' | 'email' | 'crm' | 'workflow'>('all');

  const filtered = integrations.filter(i => filter === 'all' || i.type === filter);

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">The Stack Hub</h2>
          <p className="text-slate-500 font-medium max-w-xl">
            LiveLead requires external authorization. Redirect to your provider's official portal to configure API access.
          </p>
        </div>
        
        <div className="flex bg-white p-1 rounded-2xl border border-slate-200 shadow-sm self-start overflow-x-auto no-scrollbar max-w-full">
          <button 
            onClick={() => setFilter('all')}
            className={`px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${filter === 'all' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}
          >
            All
          </button>
          <button 
            onClick={() => setFilter('email')}
            className={`px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${filter === 'email' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}
          >
            Outreach
          </button>
          <button 
            onClick={() => setFilter('crm')}
            className={`px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${filter === 'crm' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}
          >
            CRM
          </button>
          <button 
            onClick={() => setFilter('workflow')}
            className={`px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${filter === 'workflow' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}
          >
            Workflow
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filtered.map((item) => (
          <div 
            key={item.id} 
            className="bg-white border border-slate-200 rounded-[2.5rem] p-8 hover:shadow-2xl transition-all group relative flex flex-col h-full"
          >
            <div className="flex items-start justify-between mb-6">
              <div className={`w-16 h-16 ${item.color} rounded-[1.5rem] flex items-center justify-center text-3xl shadow-lg shadow-slate-100 transition-transform group-hover:scale-110`}>
                <span className="drop-shadow-md">{item.icon}</span>
              </div>
              <div className={`px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest ${item.connected ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' : 'bg-slate-50 text-slate-400 border border-slate-100'}`}>
                {item.connected ? 'Verified' : 'Setup'}
              </div>
            </div>

            <div className="flex-grow">
              <h3 className="text-xl font-black text-slate-900 mb-1">{item.name}</h3>
              <p className="text-[10px] font-black text-indigo-500 uppercase tracking-widest mb-4">{item.type} Software</p>
              <p className="text-sm font-medium text-slate-500 leading-relaxed mb-6">{item.description}</p>
            </div>

            <div className="pt-6 border-t border-slate-100 space-y-3">
              <button
                onClick={() => onAction(item.id, 'redirect')}
                className="w-full py-4 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-600 transition-all flex items-center justify-center gap-2"
              >
                Go to Portal
                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
              </button>

              <button
                onClick={() => onAction(item.id, 'toggle')}
                className={`w-full py-4 border rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${
                  item.connected 
                    ? 'bg-red-50 border-red-100 text-red-600 hover:bg-red-100' 
                    : 'bg-emerald-50 border-emerald-100 text-emerald-600 hover:bg-emerald-100'
                }`}
              >
                {item.connected ? 'Mark Offline' : 'Verify Connection'}
              </button>
            </div>
            
            {item.connected && (
              <div className="absolute top-4 right-4">
                 <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Integrations;
