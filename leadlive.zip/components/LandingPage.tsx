
import React from 'react';

interface LandingPageProps {
  onGetStarted: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onGetStarted }) => {
  return (
    <div className="bg-[#fcfcfd] min-h-screen font-sans overflow-x-hidden">
      {/* Navigation */}
      <nav className="max-w-7xl mx-auto px-4 md:px-6 h-20 md:h-24 flex items-center justify-between">
        <div className="flex items-center gap-2 md:gap-3">
          <div className="bg-indigo-600 p-1.5 md:p-2 rounded-lg md:rounded-xl shadow-lg shadow-indigo-100">
            <svg className="w-5 h-5 md:w-6 md:h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <h1 className="text-xl md:text-2xl font-black tracking-tight">
             <span className="text-slate-900">lead</span><span className="text-indigo-600">live</span>
          </h1>
        </div>
        <div className="flex items-center gap-2 md:gap-4">
          <button 
            onClick={onGetStarted}
            className="text-slate-500 hover:text-slate-900 text-[10px] font-black uppercase tracking-widest transition-colors px-2 md:px-4"
          >
            Sign In
          </button>
          <button 
            onClick={onGetStarted}
            className="bg-slate-900 text-white px-4 md:px-6 py-2.5 md:py-3 rounded-lg md:rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-600 transition-all shadow-xl shadow-slate-200"
          >
            Get Access
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-6 pt-12 md:pt-20 pb-20 md:pb-32 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-50 border border-indigo-100 rounded-full text-indigo-600 text-[9px] md:text-[10px] font-black uppercase tracking-widest mb-6 md:mb-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
          <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></span>
          Now Scanning 12+ Professional Hubs
        </div>
        <h1 className="text-4xl sm:text-6xl md:text-8xl font-black text-slate-900 tracking-tighter leading-[1.1] md:leading-[0.9] mb-6 md:mb-8 max-w-5xl mx-auto animate-in fade-in slide-in-from-bottom-8 duration-1000">
          Stop Hunting. <br className="hidden md:block" />
          <span className="text-indigo-600">Start Winning.</span>
        </h1>
        <p className="text-base md:text-2xl text-slate-500 font-medium max-w-2xl mx-auto mb-8 md:mb-12 leading-relaxed animate-in fade-in slide-in-from-bottom-12 duration-1000 delay-200">
          The first AI-powered lead engine that scans the entire web in real-time to find high-value contracts while you sleep.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-in fade-in slide-in-from-bottom-16 duration-1000 delay-300">
          <button 
            onClick={onGetStarted}
            className="w-full sm:w-auto bg-slate-900 text-white px-8 md:px-10 py-5 md:py-6 rounded-2xl md:rounded-[2rem] text-xs md:text-sm font-black uppercase tracking-[0.2em] hover:bg-indigo-600 transition-all shadow-2xl shadow-indigo-100"
          >
            Deploy Your AI Scout
          </button>
          <div className="text-[10px] md:text-xs font-bold text-slate-400 max-w-[240px] text-center sm:text-left">
            Trusted by freelancers and consultants to replace manual hunting forever.
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="bg-slate-50 py-20 md:py-32 border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12 md:mb-20">
            <h2 className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.3em] mb-4">Scale Efficiently</h2>
            <h3 className="text-3xl md:text-5xl font-black text-slate-900 tracking-tight leading-tight">Simple, outcome-based pricing.</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {/* Free Plan */}
            <div className="bg-white border border-slate-200 rounded-[2.5rem] md:rounded-[3rem] p-8 md:p-12 shadow-xl hover:shadow-2xl transition-all relative overflow-hidden">
              <div className="relative z-10">
                <h4 className="text-xl font-black text-slate-900 mb-2">Free Scout</h4>
                <div className="flex items-baseline gap-1 mb-6 md:mb-8">
                  <span className="text-4xl md:text-5xl font-black text-slate-900">$0</span>
                  <span className="text-slate-400 font-bold">/forever</span>
                </div>
                <ul className="space-y-4 mb-8 md:mb-10">
                  {['3 AI Market Scans / day', 'Basic Contact Extraction', 'Personal Lead Pipeline', 'Standard AI Proposals'].map((feat, i) => (
                    <li key={i} className="flex items-center gap-3 text-slate-600 font-medium text-sm">
                      <svg className="w-5 h-5 text-emerald-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg>
                      {feat}
                    </li>
                  ))}
                </ul>
                <button 
                  onClick={onGetStarted}
                  className="w-full py-4 bg-slate-100 text-slate-900 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-200 transition-all"
                >
                  Start Scanning
                </button>
              </div>
            </div>

            {/* Elite Plan */}
            <div className="bg-slate-900 border border-slate-800 rounded-[2.5rem] md:rounded-[3rem] p-8 md:p-12 shadow-2xl transition-all relative overflow-hidden">
              <div className="absolute top-6 right-6 md:top-8 md:right-8">
                <span className="bg-indigo-600 text-white text-[8px] md:text-[10px] font-black px-2 md:px-3 py-1 md:py-1.5 rounded-full uppercase tracking-widest">Elite Tier</span>
              </div>
              <div className="relative z-10">
                <h4 className="text-xl font-black text-white mb-2">Elite Hunter</h4>
                <div className="flex items-baseline gap-1 mb-6 md:mb-8">
                  <span className="text-4xl md:text-5xl font-black text-white">$49</span>
                  <span className="text-slate-400 font-bold">/lifetime</span>
                </div>
                <ul className="space-y-4 mb-8 md:mb-10 text-slate-300">
                  {[
                    'Unlimited Market Scans', 
                    'Deep Direct Contact Intel', 
                    'CRM Direct Integration', 
                    'Priority AI Generation',
                    'Competitor Intel Mode'
                  ].map((feat, i) => (
                    <li key={i} className="flex items-center gap-3 font-medium text-sm">
                      <svg className="w-5 h-5 text-indigo-400 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg>
                      {feat}
                    </li>
                  ))}
                </ul>
                <button 
                  onClick={onGetStarted}
                  className="w-full py-4 bg-indigo-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-500 transition-all shadow-xl"
                >
                  Join Elite Access
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-6 py-12 md:py-20 border-t border-slate-100 flex flex-col md:flex-row items-center justify-between gap-8 text-center md:text-left">
        <div className="flex items-center gap-3">
          <div className="bg-indigo-600 p-2 rounded-xl">
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
          </div>
          <span className="text-xl font-black tracking-tighter">
            <span className="text-slate-900">lead</span><span className="text-indigo-600">live</span>
          </span>
        </div>
        <div className="flex flex-wrap justify-center gap-6 md:gap-8">
           {["Privacy", "Terms", "Support"].map(link => (
             <a key={link} href="#" className="text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-indigo-600 transition-colors">{link}</a>
           ))}
        </div>
        <p className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">© 2025 leadlive. v3.2 Alpha</p>
      </footer>
    </div>
  );
};

export default LandingPage;
