
import React, { useState, useEffect } from 'react';
import { UserProfile, TeamMember } from '../types.ts';

interface SettingsProps {
  profile: UserProfile;
  onUpdate: (profile: UserProfile) => void;
}

const Settings: React.FC<SettingsProps> = ({ profile, onUpdate }) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'team' | 'admin'>('profile');
  const [formData, setFormData] = useState<UserProfile>(profile);
  const [isSaving, setIsSaving] = useState(false);
  const [workspaceName, setWorkspaceName] = useState('Growth Ops');
  
  const [members, setMembers] = useState<TeamMember[]>([
    { id: '1', fullName: profile.fullName, email: profile.email, role: 'owner' },
    { id: '2', fullName: 'Sarah Dev', email: 'sarah@growth.io', role: 'member' }
  ]);

  const [inviteEmail, setInviteEmail] = useState('');

  useEffect(() => {
    setFormData(profile);
  }, [profile]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setTimeout(() => {
      onUpdate(formData);
      setIsSaving(false);
    }, 600);
  };

  const handleInvite = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteEmail) return;
    const newMember: TeamMember = {
      id: Math.random().toString(),
      fullName: 'Pending Invite',
      email: inviteEmail,
      role: 'member'
    };
    setMembers([...members, newMember]);
    setInviteEmail('');
  };

  return (
    <div className="space-y-6 md:space-y-8 animate-in fade-in slide-in-from-bottom-4">
      <div className="flex bg-white p-1 rounded-2xl border border-slate-200 shadow-sm w-fit">
        <button onClick={() => setActiveTab('profile')} className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'profile' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400'}`}>My Profile</button>
        <button onClick={() => setActiveTab('team')} className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'team' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400'}`}>Team Hub</button>
        {profile.role === 'owner' && (
          <button onClick={() => setActiveTab('admin')} className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'admin' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400'}`}>Admin Config</button>
        )}
      </div>

      {activeTab === 'profile' && (
        <div className="bg-white rounded-[2.5rem] border border-slate-200 p-8 sm:p-12 shadow-xl shadow-slate-200/50">
          <div className="mb-10">
            <h2 className="text-3xl font-black text-slate-900 tracking-tight">Identity Settings</h2>
            <p className="text-slate-500 font-medium">Manage your professional bio and target parameters.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-3 ml-1">Full Business Name</label>
                <input
                  type="text"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-600 outline-none transition-all font-medium"
                />
              </div>
              <div>
                <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-3 ml-1">Primary Niche</label>
                <input
                  type="text"
                  value={formData.niche}
                  onChange={(e) => setFormData({ ...formData, niche: e.target.value })}
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-600 outline-none transition-all font-medium"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-3 ml-1">Professional Bio</label>
              <textarea
                value={formData.bio}
                onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-600 outline-none transition-all font-medium h-32 resize-none"
              />
            </div>

            <button type="submit" disabled={isSaving} className="bg-slate-900 text-white px-10 py-5 rounded-2xl font-black text-sm uppercase tracking-[0.2em] hover:bg-indigo-600 transition-all shadow-xl">
              {isSaving ? 'Syncing...' : 'Save Profile'}
            </button>
          </form>
        </div>
      )}

      {activeTab === 'team' && (
        <div className="space-y-6 md:space-y-8">
          <div className="bg-white rounded-[2.5rem] border border-slate-200 p-8 sm:p-12 shadow-xl">
            <h2 className="text-3xl font-black text-slate-900 tracking-tight mb-8">Workspace Control</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="space-y-6">
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Workspace Name</label>
                  <input
                    type="text"
                    value={workspaceName}
                    onChange={(e) => setWorkspaceName(e.target.value)}
                    className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold"
                  />
                </div>
                <div className="p-6 bg-indigo-50 rounded-2xl border border-indigo-100">
                  <h4 className="text-[10px] font-black text-indigo-600 uppercase tracking-widest mb-2">Team Insight</h4>
                  <p className="text-xs font-medium text-indigo-700 leading-relaxed">Leads shortlisted by any team member are instantly visible to the whole workspace.</p>
                </div>
              </div>
              
              <div className="space-y-6">
                 <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Active Members ({members.length})</h4>
                 <div className="space-y-3">
                    {members.map(m => (
                      <div key={m.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-slate-900 flex items-center justify-center text-[10px] font-black text-white uppercase">
                            {m.fullName.substring(0,2)}
                          </div>
                          <div>
                            <p className="text-xs font-black text-slate-900">{m.fullName}</p>
                            <p className="text-[9px] font-bold text-slate-400">{m.email}</p>
                          </div>
                        </div>
                        <span className={`text-[8px] font-black uppercase px-2 py-1 rounded-lg ${m.role === 'owner' ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-500'}`}>
                          {m.role}
                        </span>
                      </div>
                    ))}
                 </div>

                 <form onSubmit={handleInvite} className="flex gap-2">
                   <input
                    type="email"
                    placeholder="teammate@email.com"
                    value={inviteEmail}
                    onChange={(e) => setInviteEmail(e.target.value)}
                    className="flex-grow px-5 py-3 bg-white border border-slate-200 rounded-xl text-xs font-medium"
                   />
                   <button type="submit" className="bg-slate-900 text-white px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest">Invite</button>
                 </form>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'admin' && (
        <div className="bg-white rounded-[2.5rem] border border-slate-200 p-8 sm:p-12 shadow-xl shadow-slate-200/50">
          <div className="mb-10">
            <h2 className="text-2xl font-black text-slate-900 tracking-tight">Financial Config</h2>
            <p className="text-slate-500 font-medium">Workspace-wide billing and PayPal settings.</p>
          </div>
          
          <div className="space-y-6">
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 ml-1">PayPal Client ID</label>
              <input
                type="text"
                value={formData.paypalClientId || ''}
                onChange={(e) => setFormData({ ...formData, paypalClientId: e.target.value })}
                className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-mono text-xs"
                placeholder="AX7H-..."
              />
            </div>
            
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 ml-1">Business Email</label>
              <input
                type="email"
                value={formData.paypalEmail || ''}
                onChange={(e) => setFormData({ ...formData, paypalEmail: e.target.value })}
                className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-medium"
              />
            </div>

            <button onClick={handleSubmit} className="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest">Update Global Config</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Settings;
