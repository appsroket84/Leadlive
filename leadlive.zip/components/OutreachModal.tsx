
import React, { useState } from 'react';
import { Lead, Integration } from '../types.ts';

interface OutreachModalProps {
  lead: Lead;
  onClose: () => void;
  onSend: (leadId: string, content: string, softwareId: string) => void;
  connectedEmails: Integration[];
}

const OutreachModal: React.FC<OutreachModalProps> = ({ lead, onClose, onSend, connectedEmails }) => {
  const [content, setContent] = useState(lead.proposalTemplate || '');
  const [selectedSoftware, setSelectedSoftware] = useState(connectedEmails[0]?.id || '');
  const [subject, setSubject] = useState(`Regarding the ${lead.title} position`);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
      <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={onClose}></div>
      <div className="bg-white w-full max-w-2xl rounded-[3rem] shadow-2xl relative z-10 overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="bg-slate-50 border-b border-slate-200 p-8 flex items-center justify-between">
          <div>
            <h3 className="text-xl font-black text-slate-900 tracking-tight">Compose Outreach</h3>
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mt-1">Target: {lead.company}</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full transition-colors">
            <svg className="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        <div className="p-8 space-y-6">
          {connectedEmails.length === 0 ? (
            <div className="p-10 text-center bg-slate-50 rounded-[2rem] border-2 border-dashed border-slate-200">
              <p className="text-slate-500 font-bold mb-4">No email software connected.</p>
              <button className="text-indigo-600 font-black text-xs uppercase tracking-widest underline">Go to Integrations</button>
            </div>
          ) : (
            <>
              <div className="space-y-4">
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1 mb-2 block">Send via</label>
                  <select 
                    value={selectedSoftware}
                    onChange={(e) => setSelectedSoftware(e.target.value)}
                    className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold text-slate-900 focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all"
                  >
                    {connectedEmails.map(app => <option key={app.id} value={app.id}>{app.name} (Active)</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1 mb-2 block">Subject Line</label>
                  <input 
                    type="text" 
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold text-slate-900 focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1 mb-2 block">Proposal Content</label>
                  <textarea 
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    className="w-full h-64 px-5 py-5 bg-slate-50 border border-slate-200 rounded-2xl font-medium text-slate-600 focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all resize-none leading-relaxed"
                  />
                </div>
              </div>

              <div className="flex gap-4">
                <button 
                  onClick={() => onSend(lead.id, content, selectedSoftware)}
                  className="flex-grow bg-slate-900 text-white py-5 rounded-2xl font-black text-sm uppercase tracking-[0.2em] hover:bg-indigo-600 transition-all shadow-xl shadow-indigo-100 flex items-center justify-center gap-3"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
                  Finalize & Send
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default OutreachModal;
