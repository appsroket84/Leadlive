
import React, { useState, useEffect } from 'react';
import { SearchParams } from '../types.ts';

const STORAGE_KEY = 'livelead_config';
const SAVED_SEARCH_KEY = 'livelead_saved_search';
const AVAILABLE_PLATFORMS = [
  'Upwork', 'LinkedIn', 'Fiverr', 'Freelancer', 
  'Toptal', 'Guru', '99designs', 'PeoplePerHour', 
  'Indeed', 'Wellfound', 'Dribbble', 'Behance', 'FlexJobs'
];

const NOTIFICATION_FREQUENCIES = [
  { id: 'instant', label: 'Instant' },
  { id: 'daily', label: 'Daily Digest' },
  { id: 'weekly', label: 'Weekly Report' }
];

interface SearchFormProps {
  onSearch: (params: SearchParams) => void;
  isLoading: boolean;
  initialParams?: SearchParams | null;
}

const SearchForm: React.FC<SearchFormProps> = ({ onSearch, isLoading, initialParams }) => {
  const [niche, setNiche] = useState('Web Development - React & Node.js');
  const [location, setLocation] = useState('');
  const [experienceLevel, setExperienceLevel] = useState('Expert');
  const [budgetMin, setBudgetMin] = useState<number>(1000);
  const [platforms, setPlatforms] = useState<string[]>(['Upwork', 'LinkedIn', 'Fiverr', 'Toptal']);
  const [jobType, setJobType] = useState('Freelance');
  const [remoteOption, setRemoteOption] = useState('Remote');
  const [keywords, setKeywords] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [autoNotify, setAutoNotify] = useState(false);
  const [notificationFrequency, setNotificationFrequency] = useState('daily');
  
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saved'>('idle');
  const [searchSaveStatus, setSearchSaveStatus] = useState<'idle' | 'saved'>('idle');
  
  const [emailError, setEmailError] = useState<string | null>(null);
  const [budgetError, setBudgetError] = useState<string | null>(null);
  const [keywordsError, setKeywordsError] = useState<string | null>(null);

  const validateEmail = (email: string) => {
    if (!email) return true;
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  };

  useEffect(() => {
    // Priority: 1. Passed initialParams, 2. Stored Storage, 3. Defaults
    const stored = localStorage.getItem(STORAGE_KEY);
    const base = initialParams || (stored ? JSON.parse(stored) : null);
    
    if (base) {
      setNiche(base.niche || '');
      setLocation(base.location || '');
      setExperienceLevel(base.experienceLevel || 'Expert');
      setBudgetMin(base.budgetMin || 0);
      setPlatforms(base.platforms || ['Upwork', 'LinkedIn', 'Fiverr']);
      setJobType(base.jobType || 'Freelance');
      setRemoteOption(base.remoteOption || 'Remote');
      setKeywords(base.keywords || '');
      setUserEmail(base.userEmail || '');
      setAutoNotify(!!base.autoNotify);
      setNotificationFrequency(base.notificationFrequency || 'daily');
    }
  }, [initialParams]);

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setUserEmail(val);
    if (val && !validateEmail(val)) {
      setEmailError('Please enter a valid email address');
    } else {
      setEmailError(null);
    }
  };

  const handleBudgetChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    setBudgetMin(val);
    if (val < 0) {
      setBudgetError('Budget cannot be negative');
    } else {
      setBudgetError(null);
    }
  };

  const handleKeywordsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setKeywords(val);
    if (val.length > 100) {
      setKeywordsError('Keywords too long (max 100 chars)');
    } else {
      setKeywordsError(null);
    }
  };

  const handlePlatformToggle = (platform: string) => {
    setPlatforms(prev => 
      prev.includes(platform) 
        ? prev.filter(p => p !== platform) 
        : [...prev, platform]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (userEmail && !validateEmail(userEmail)) return;
    if (budgetError || keywordsError) return;
    if (autoNotify && !userEmail) {
      setEmailError('Email is required for auto-notifications');
      return;
    }
    onSearch({ 
      niche, location, experienceLevel, budgetMin, platforms, 
      jobType, remoteOption, keywords, userEmail, autoNotify,
      notificationFrequency
    });
  };

  const handleSave = () => {
    if (emailError || budgetError || keywordsError) return;
    const config: SearchParams = { 
      niche, location, experienceLevel, budgetMin, platforms, 
      jobType, remoteOption, keywords, userEmail, autoNotify,
      notificationFrequency
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
    setSaveStatus('saved');
    setTimeout(() => setSaveStatus('idle'), 2000);
  };

  const handleSaveSearch = () => {
    if (budgetError || keywordsError) return;
    const searchData = { 
      niche, location, experienceLevel, budgetMin, platforms, 
      jobType, remoteOption, keywords, notificationFrequency 
    };
    localStorage.setItem(SAVED_SEARCH_KEY, JSON.stringify(searchData));
    setSearchSaveStatus('saved');
    setTimeout(() => setSearchSaveStatus('idle'), 2000);
  };

  return (
    <div className="space-y-4">
      <form onSubmit={handleSubmit} className="bg-white p-10 rounded-[2.5rem] shadow-xl border border-slate-200 space-y-8">
        <div className="space-y-6">
          <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest">Targeting Config</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Your Niche / Skillset</label>
              <input 
                type="text" 
                value={niche}
                onChange={(e) => setNiche(e.target.value)}
                placeholder="e.g. Content Marketing for SaaS"
                className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-600 outline-none transition-all font-bold"
              />
            </div>

            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Location Preference</label>
              <div className="relative">
                <input 
                  type="text" 
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g. USA, London, or Worldwide"
                  className="w-full pl-12 pr-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-600 outline-none transition-all font-bold"
                />
                <svg className="w-5 h-5 absolute left-4 top-4.5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Deep Keywords</label>
            <input 
              type="text" 
              value={keywords}
              onChange={handleKeywordsChange}
              placeholder="Specific terms (e.g. React, Python, SEO)"
              className={`w-full px-5 py-4 bg-slate-50 border rounded-2xl focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all font-bold ${
                keywordsError ? 'border-red-300 bg-red-50' : 'border-slate-200 focus:border-indigo-600'
              }`}
            />
            {keywordsError && <p className="mt-1 text-xs text-red-500 font-black uppercase">{keywordsError}</p>}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Job Type</label>
              <select 
                value={jobType}
                onChange={(e) => setJobType(e.target.value)}
                className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 outline-none font-bold"
              >
                <option>Freelance</option>
                <option>Contract</option>
                <option>Full-time</option>
                <option>Part-time</option>
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Experience</label>
              <select 
                value={experienceLevel}
                onChange={(e) => setExperienceLevel(e.target.value)}
                className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 outline-none font-bold"
              >
                <option>Entry</option>
                <option>Intermediate</option>
                <option>Expert</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 ml-1">Marketplaces</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 max-h-60 overflow-y-auto pr-1">
              {AVAILABLE_PLATFORMS.map((platform) => (
                <label 
                  key={platform} 
                  className={`flex items-center gap-3 p-3 rounded-2xl border transition-all cursor-pointer ${
                    platforms.includes(platform) 
                    ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-100' 
                    : 'bg-white border-slate-200 text-slate-500 hover:border-slate-300'
                  }`}
                >
                  <input 
                    type="checkbox"
                    className="sr-only"
                    checked={platforms.includes(platform)}
                    onChange={() => handlePlatformToggle(platform)}
                  />
                  <span className="text-[11px] font-black uppercase tracking-widest truncate">{platform}</span>
                </label>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-6 pt-6 border-t border-slate-100">
          <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest">Automation Settings</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
             <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Min Budget ($)</label>
              <input 
                type="number" 
                value={budgetMin}
                onChange={handleBudgetChange}
                className={`w-full px-5 py-4 bg-slate-50 border rounded-2xl focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all font-bold ${
                  budgetError ? 'border-red-300 bg-red-50' : 'border-slate-200 focus:border-indigo-600'
                }`}
              />
              {budgetError && <p className="mt-1 text-xs text-red-500 font-black uppercase">{budgetError}</p>}
            </div>
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Work Style</label>
              <select 
                value={remoteOption}
                onChange={(e) => setRemoteOption(e.target.value)}
                className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 outline-none font-bold"
              >
                <option>Remote</option>
                <option>On-site</option>
                <option>Hybrid</option>
              </select>
            </div>
          </div>

          <div className="space-y-6 p-6 bg-slate-50 rounded-[2rem] border border-slate-100">
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Notification Recipient</label>
              <div className="relative">
                <input 
                  type="email" 
                  value={userEmail}
                  onChange={handleEmailChange}
                  placeholder="your@email.com"
                  className={`w-full pl-12 pr-5 py-4 bg-white border rounded-2xl focus:ring-4 focus:ring-indigo-500/10 outline-none transition-all font-bold ${
                    emailError ? 'border-red-300 bg-red-50' : 'border-slate-200 focus:border-indigo-600'
                  }`}
                />
                <svg className={`w-5 h-5 absolute left-4 top-4.5 ${emailError ? 'text-red-400' : 'text-slate-400'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </div>
              {emailError && <p className="mt-1.5 text-xs font-black uppercase text-red-500">{emailError}</p>}
            </div>

            <label className="flex items-center gap-4 cursor-pointer group">
              <div className="relative inline-flex items-center">
                <input 
                  type="checkbox" 
                  checked={autoNotify}
                  onChange={(e) => setAutoNotify(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-14 h-8 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[4px] after:left-[4px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-indigo-600"></div>
              </div>
              <span className="text-sm font-bold text-slate-700 group-hover:text-slate-900 transition-colors">
                Enable 24/7 AI Scout Notifications
              </span>
            </label>

            {autoNotify && (
              <div className="pt-2 animate-in fade-in slide-in-from-top-2 duration-300">
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 px-1">Report Frequency</label>
                <div className="flex gap-3">
                  {NOTIFICATION_FREQUENCIES.map((freq) => (
                    <button
                      key={freq.id}
                      type="button"
                      onClick={() => setNotificationFrequency(freq.id)}
                      className={`flex-1 py-3 px-4 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${
                        notificationFrequency === freq.id 
                          ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg' 
                          : 'bg-white border-slate-200 text-slate-500 hover:border-indigo-300'
                      }`}
                    >
                      {freq.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="flex flex-col gap-4 pt-6">
          <button 
            disabled={isLoading || !!emailError || !!budgetError || !!keywordsError}
            type="submit"
            className="w-full bg-slate-900 text-white py-6 rounded-2xl font-black text-sm uppercase tracking-[0.3em] hover:bg-indigo-600 transition-all flex items-center justify-center gap-3 disabled:opacity-50 shadow-2xl shadow-indigo-100"
          >
            {isLoading ? (
              <span className="flex items-center gap-3">
                <svg className="animate-spin h-5 w-5" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Deploying Scouts...
              </span>
            ) : 'Scan The Entire Web'}
          </button>
          
          <div className="grid grid-cols-2 gap-4">
            <button 
              type="button"
              onClick={handleSave}
              disabled={!!emailError || !!budgetError || !!keywordsError}
              className={`py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest border transition-all flex items-center justify-center gap-2 ${
                saveStatus === 'saved' ? 'bg-emerald-50 border-emerald-200 text-emerald-600' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50 disabled:opacity-50'
              }`}
            >
              {saveStatus === 'saved' ? 'Settings Saved!' : 'Save Defaults'}
            </button>

            <button 
              type="button"
              onClick={handleSaveSearch}
              disabled={!!budgetError || !!keywordsError}
              className={`py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest border transition-all flex items-center justify-center gap-2 ${
                searchSaveStatus === 'saved' ? 'bg-indigo-50 border-indigo-200 text-indigo-600' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50 disabled:opacity-50'
              }`}
            >
              {searchSaveStatus === 'saved' ? 'Search Locked!' : 'Lock Search'}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default SearchForm;
