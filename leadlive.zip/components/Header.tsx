
import React from 'react';
import { supabase } from '../lib/supabase.ts';
import { ViewType, UserProfile } from '../types.ts';

interface HeaderProps {
  session?: any;
  profile?: UserProfile | null;
  onNavigate?: (view: ViewType) => void;
  activeView?: ViewType;
}

const Header: React.FC<HeaderProps> = ({ session, profile, onNavigate, activeView }) => {
  const handleSignOut = async () => {
    if (supabase) {
      await supabase.auth.signOut();
    }
  };

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-[60] backdrop-blur-md bg-white/80">
      <div className="max-w-7xl mx-auto px-4 h-16 md:h-20 flex items-center justify-between gap-4">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 md:gap-3 cursor-pointer shrink-0" onClick={() => onNavigate?.('home')}>
            <div className="bg-indigo-600 p-1.5 md:p-2.5 rounded-lg md:rounded-2xl shadow-lg shadow-indigo-100">
              <svg className="w-5 h-5 md:w-6 md:h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <h1 className="text-xl md:text-2xl font-black tracking-tight whitespace-nowrap">
              <span className="text-slate-900">lead</span><span className="text-indigo-600">live</span>
            </h1>
          </div>

          {profile?.teamId && (
            <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-full">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Team Workspace</span>
            </div>
          )}
        </div>
        
        <nav className="flex items-center gap-2 md:gap-6 overflow-hidden">
          {session ? (
            <div className="flex items-center gap-2 md:gap-6">
              <div className="hidden sm:block text-right">
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">{profile?.role === 'owner' ? 'Admin' : 'Member'}</p>
                <p className="text-[10px] font-bold text-slate-900 truncate max-w-[100px] md:max-w-[150px]">{session.user.email}</p>
              </div>
              <button 
                onClick={handleSignOut}
                className="bg-slate-50 text-slate-600 px-3 md:px-6 py-2 rounded-lg md:rounded-xl text-[10px] font-black uppercase tracking-widest border border-slate-200 hover:bg-red-50 hover:text-red-600 transition-all shrink-0"
              >
                Exit
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-4">
               <span className="text-[9px] font-black text-slate-300 uppercase tracking-widest">V 3.5.0 Team</span>
            </div>
          )}
        </nav>
      </div>
    </header>
  );
};

export default Header;
