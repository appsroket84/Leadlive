
import React from 'react';
import { UserProfile } from '../types.ts';

interface DashboardHomeProps {
  profile: UserProfile;
  leadsFound: number;
  savedCount: number;
  onNavigate: (view: 'scout' | 'saved') => void;
}

const DashboardHome: React.FC<DashboardHomeProps> = ({ profile, leadsFound, savedCount, onNavigate }) => {
  return (
    <div className="space-y-6 md:space-y-10 animate-in fade-in slide-in-from-bottom-4">
      <div className="bg-white border border-slate-200 rounded-[2rem] p-6 md:p-14 relative overflow-hidden shadow-xl shadow-slate-200/50">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-50 rounded-full -translate-y-1/2 translate-x-1/2 opacity-50 blur-3xl"></div>
        <div className="relative z-10">
          <div className="flex flex-wrap items-center gap-2 md:gap-3 mb-4">
            <div className="bg-indigo-600 text-white text-[8px] md:text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest">
              {profile.industry} Lead Engine
            </div>
            <div className="bg-slate-900 text-white text-[8px] md:text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest border border-slate-800">
              Workspace Sync ON
            </div>
          </div>
          <h2 className="text-3xl md:text-4xl font-black text-slate-900 mb-3 md:mb-4 tracking-tight leading-tight">
            Hi, <span className="text-indigo-600">{profile.fullName.split(' ')[0]}</span>
          </h2>
          <p className="text-slate-500 text-base md:text-lg font-medium max-w-2xl leading-relaxed">
            Your personal <span className="font-black"><span className="text-slate-900">lead</span><span className="text-indigo-600">live</span></span> scout is collaborating with your team to find <span className="text-slate-900 font-bold underline decoration-indigo-200 underline-offset-4">{profile.niche || 'premium'}</span> contracts.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
        <div className="bg-white border border-slate-200 rounded-3xl p-6 md:p-8 shadow-lg flex flex-col justify-between group hover:border-indigo-600 transition-all">
          <div className="bg-indigo-50 w-10 h-10 md:w-12 md:h-12 rounded-xl md:rounded-2xl flex items-center justify-center text-indigo-600 mb-4 md:mb-6">
            <svg className="w-5 h-5 md:w-6 md:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
          </div>
          <div>
            <div className="text-3xl md:text-4xl font-black text-slate-900 mb-1">{leadsFound}</div>
            <div className="text-[9px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest">Global Scan Matches</div>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-3xl p-6 md:p-8 shadow-lg flex flex-col justify-between group hover:border-emerald-600 transition-all">
          <div className="bg-emerald-50 w-10 h-10 md:w-12 md:h-12 rounded-xl md:rounded-2xl flex items-center justify-center text-emerald-600 mb-4 md:mb-6">
            <svg className="w-5 h-5 md:w-6 md:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
          </div>
          <div>
            <div className="text-3xl md:text-4xl font-black text-slate-900 mb-1">{savedCount}</div>
            <div className="text-[9px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest">Team Shortlist</div>
          </div>
        </div>

        <div className="bg-slate-900 rounded-3xl p-6 md:p-8 shadow-xl text-white relative overflow-hidden group sm:col-span-2 lg:col-span-1">
          <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500 rounded-full blur-3xl opacity-20"></div>
          <div className="bg-white/10 w-10 h-10 md:w-12 md:h-12 rounded-xl md:rounded-2xl flex items-center justify-center mb-4 md:mb-6">
            <svg className="w-5 h-5 md:w-6 md:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
          </div>
          <div>
            <div className="text-lg md:text-xl font-black mb-1">Live Team Feed</div>
            <div className="text-[8px] md:text-[9px] font-bold text-slate-400 uppercase tracking-widest">Workspace is Active</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-6">
          <button 
            onClick={() => onNavigate('scout')}
            className="bg-white border border-slate-200 p-6 md:p-10 rounded-3xl hover:border-indigo-600 transition-all text-left group shadow-sm hover:shadow-2xl relative overflow-hidden"
          >
            <div className="absolute bottom-0 right-0 w-32 h-32 bg-indigo-50 rounded-full translate-y-1/2 translate-x-1/2 -z-10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <h3 className="text-xl md:text-2xl font-black text-slate-900 mb-2 group-hover:text-indigo-600 transition-colors">Launch Market Scan</h3>
            <p className="text-slate-500 font-medium text-xs md:text-sm leading-relaxed">Refresh your AI scouts with updated team targeting parameters.</p>
          </button>
          <button 
            onClick={() => onNavigate('saved')}
            className="bg-white border border-slate-200 p-6 md:p-10 rounded-3xl hover:border-emerald-600 transition-all text-left group shadow-sm hover:shadow-2xl relative overflow-hidden"
          >
            <div className="absolute bottom-0 right-0 w-32 h-32 bg-emerald-50 rounded-full translate-y-1/2 translate-x-1/2 -z-10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <h3 className="text-xl md:text-2xl font-black text-slate-900 mb-2 group-hover:text-emerald-600 transition-colors">Shared Pipeline</h3>
            <p className="text-slate-500 font-medium text-xs md:text-sm leading-relaxed">Review collective leads and manage the team conversion funnel.</p>
          </button>
        </div>

        <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-lg">
          <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-6">Workspace Activity</h4>
          <div className="space-y-6">
             {[
               { user: 'Sarah', action: 'shortlisted', target: 'AI Engineer Role', time: '2m ago' },
               { user: 'You', action: 'synced', target: 'HubSpot CRM', time: '14m ago' },
               { user: 'Admin', action: 'updated', target: 'Niche Parameters', time: '1h ago' }
             ].map((act, i) => (
               <div key={i} className="flex gap-4 items-start">
                  <div className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center text-[10px] font-black text-slate-400 shrink-0 border border-slate-100">
                    {act.user.charAt(0)}
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-700">
                      <span className="text-indigo-600">{act.user}</span> {act.action} <span className="text-slate-900">{act.target}</span>
                    </p>
                    <p className="text-[9px] font-black text-slate-300 uppercase mt-1">{act.time}</p>
                  </div>
               </div>
             ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardHome;
