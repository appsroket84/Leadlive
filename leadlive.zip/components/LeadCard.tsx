
import React, { useState, useMemo, useEffect } from 'react';
import { Lead, LeadStatus, SocialLink } from '../types.ts';
import { fetchMarketNews } from '../services/geminiService.ts';
import { marked } from 'marked';

interface LeadCardProps {
  leads: Lead[];
  summary?: string;
  sources?: any[];
  userEmail?: string;
  isSavedView?: boolean;
  savedIds?: Set<string>;
  onToggleSave?: (lead: Lead) => void;
  onStatusChange?: (id: string, status: LeadStatus) => void;
  onSyncCrm?: (lead: Lead) => void;
  hasConnectedCrm?: boolean;
  onLoadMore?: () => void;
  isLoadingMore?: boolean;
}

type SortOption = 'newest' | 'budget-high' | 'match' | 'duration-long' | 'duration-short';

/**
 * A safe Markdown renderer component that handles async parsing from marked
 */
const MarkdownRenderer = ({ content, className }: { content: string; className?: string }) => {
  const [html, setHtml] = useState('');

  useEffect(() => {
    const parse = async () => {
      const result = await marked.parse(content || '');
      setHtml(result);
    };
    parse();
  }, [content]);

  return (
    <div 
      className={`markdown-content ${className}`} 
      dangerouslySetInnerHTML={{ __html: html }} 
    />
  );
};

export default function LeadCard({ 
  leads, 
  summary, 
  sources, 
  isSavedView, 
  savedIds, 
  onToggleSave, 
  onStatusChange,
  onSyncCrm,
  hasConnectedCrm,
  onLoadMore,
  isLoadingMore
}: LeadCardProps) {
  const [sortBy, setSortBy] = useState<SortOption>('match');
  const [expandedLeads, setExpandedLeads] = useState<Record<string, boolean>>({});
  const [activeTab, setActiveTab] = useState<Record<string, 'proposal' | 'step1' | 'step2' | 'step3' | 'intel'>>({});
  const [copyStatus, setCopyStatus] = useState<Record<string, string>>({});
  const [showShare, setShowShare] = useState<Record<string, boolean>>({});
  
  // News state
  const [newsData, setNewsData] = useState<Record<string, { text: string; links: { title: string; uri: string }[] }>>({});
  const [fetchingNews, setFetchingNews] = useState<Record<string, boolean>>({});
  const [highlightingProposal, setHighlightingProposal] = useState<Record<string, boolean>>({});

  const toggleExpand = (id: string) => {
    setExpandedLeads(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text || '');
    setCopyStatus(prev => ({ ...prev, [id]: 'COPIED!' }));
    setTimeout(() => setCopyStatus(prev => ({ ...prev, [id]: '' })), 2000);
  };

  const handleApplyWithAI = (lead: Lead) => {
    setActiveTab(prev => ({ ...prev, [lead.id]: 'proposal' }));
    setHighlightingProposal(prev => ({ ...prev, [lead.id]: true }));
    setTimeout(() => {
      setHighlightingProposal(prev => ({ ...prev, [lead.id]: false }));
    }, 1000);
  };

  const handleGetNews = async (lead: Lead) => {
    if (fetchingNews[lead.id]) return;
    setFetchingNews(prev => ({ ...prev, [lead.id]: true }));
    try {
      const data = await fetchMarketNews(lead.company, lead.title);
      setNewsData(prev => ({ ...prev, [lead.id]: data }));
    } finally {
      setFetchingNews(prev => ({ ...prev, [lead.id]: false }));
    }
  };

  const copyAllContactInfo = (lead: Lead) => {
    const info = [];
    info.push(`Lead: ${lead.title} at ${lead.company}`);
    if (lead.hiringContactName) info.push(`Contact: ${lead.hiringContactName}`);
    if (lead.email) info.push(`Email: ${lead.email}`);
    if (lead.phone) info.push(`Phone: ${lead.phone}`);
    if (lead.socialLinks && lead.socialLinks.length > 0) {
      info.push('Socials:');
      lead.socialLinks.forEach(s => info.push(`- ${s.platform}: ${s.url}`));
    }
    const text = info.join('\n');
    handleCopy(lead.id + '-all-contact', text);
  };

  const sortedLeads = useMemo(() => {
    const leadsCopy = [...leads];
    switch (sortBy) {
      case 'newest': return leadsCopy.sort((a, b) => (b.postedAt || '').localeCompare(a.postedAt || ''));
      case 'budget-high': return leadsCopy.sort((a, b) => parseFloat(b.budget?.replace(/[^0-9.]/g, '') || '0') - parseFloat(a.budget?.replace(/[^0-9.]/g, '') || '0'));
      case 'match': return leadsCopy.sort((a, b) => b.matchScore - a.matchScore);
      case 'duration-long': return leadsCopy.sort((a, b) => (b.durationWeeks || 0) - (a.durationWeeks || 0));
      case 'duration-short': return leadsCopy.sort((a, b) => (a.durationWeeks || 0) - (b.durationWeeks || 0));
      default: return leadsCopy;
    }
  }, [leads, sortBy]);

  return (
    <div className="space-y-6 md:space-y-8 pb-10 md:pb-20">
      {/* AI Briefing Card */}
      {!isSavedView && summary && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-10 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-1/2 h-full bg-indigo-600/10 blur-3xl rounded-full"></div>
          <div className="relative z-10">
            <h4 className="text-indigo-400 font-black uppercase tracking-widest text-[9px] mb-2 md:mb-3">Market Intelligence</h4>
            <div className="text-white leading-relaxed font-semibold text-base md:text-xl max-w-3xl">
              <MarkdownRenderer content={summary} />
            </div>
          </div>
        </div>
      )}

      {/* Grid Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between px-2 gap-4">
        <div className="flex flex-wrap items-center gap-3">
           <h3 className="text-xl md:text-2xl font-black text-slate-900 shrink-0">{isSavedView ? 'Pipeline' : 'Scan Results'}</h3>
           <span className="bg-indigo-50 text-indigo-600 text-[9px] font-black px-2.5 py-1.5 rounded-lg uppercase border border-indigo-100">{leads.length} Leads</span>
        </div>
        <select 
          value={sortBy} 
          onChange={(e) => setSortBy(e.target.value as SortOption)} 
          className="w-full sm:w-auto bg-white border border-slate-200 text-slate-900 text-[9px] font-black uppercase tracking-widest rounded-xl px-4 py-2.5 shadow-sm outline-none cursor-pointer"
        >
          <option value="match">Match Accuracy</option>
          <option value="newest">Recent Posts</option>
          <option value="budget-high">Budget: High</option>
          <option value="duration-long">Term: Long</option>
          <option value="duration-short">Term: Short</option>
        </select>
      </div>

      {/* Lead Cards Grid */}
      <div className="grid grid-cols-1 gap-6">
        {sortedLeads.length === 0 ? (
          <div className="bg-white border-2 border-dashed border-slate-200 rounded-3xl p-12 md:p-24 text-center">
            <p className="text-slate-400 font-black uppercase tracking-widest text-[10px]">No matches found in current scan</p>
          </div>
        ) : sortedLeads.map((lead) => {
          const lActiveTab = activeTab[lead.id] || 'intel';
          const hasNews = !!newsData[lead.id];
          const isFetching = fetchingNews[lead.id];
          const isHighlighted = highlightingProposal[lead.id];
          
          return (
            <div key={lead.id} className="bg-white border border-slate-200 rounded-3xl p-6 md:p-8 hover:shadow-2xl transition-all duration-300 group">
              <div className="flex flex-col xl:flex-row gap-6 md:gap-10">
                
                {/* Core Info */}
                <div className="flex-grow space-y-5">
                  <div className="flex items-center justify-between">
                    <div className="flex flex-wrap items-center gap-2">
                      <div className="bg-slate-50 text-slate-500 px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-tighter border border-slate-100">
                        {lead.platform}
                      </div>
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{lead.postedAt}</span>
                      {lead.duration && (
                        <div className="hidden sm:flex items-center gap-1 bg-indigo-50 text-indigo-600 px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-tighter border border-indigo-100">
                          {lead.duration}
                        </div>
                      )}
                    </div>
                    
                    <button 
                      onClick={() => onToggleSave?.(lead)}
                      className={`p-2 rounded-xl transition-all ${
                        savedIds?.has(lead.id) ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-50 text-slate-400 hover:bg-indigo-50 hover:text-indigo-600'
                      }`}
                    >
                      <svg className="w-5 h-5" fill={savedIds?.has(lead.id) ? "currentColor" : "none"} stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" /></svg>
                    </button>
                  </div>

                  <div>
                    <h3 className="text-xl md:text-2xl font-black text-slate-900 group-hover:text-indigo-600 transition-colors mb-2 leading-tight">{lead.title}</h3>
                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs font-bold text-slate-500">
                       <span className="text-slate-900">{lead.company}</span>
                       <span className="text-indigo-600">{lead.budget || "Market Rate"}</span>
                    </div>
                  </div>

                  <div className={`relative transition-all duration-500 overflow-hidden ${!expandedLeads[lead.id] ? 'max-h-20' : 'max-h-[1000px]'}`}>
                    <MarkdownRenderer 
                      content={lead.description} 
                      className="text-slate-600 text-sm md:text-base leading-relaxed font-medium" 
                    />
                    {!expandedLeads[lead.id] && <div className="absolute bottom-0 left-0 w-full h-8 bg-gradient-to-t from-white to-transparent"></div>}
                  </div>

                  <div className="flex flex-wrap gap-2 items-center">
                    {lead.skills?.slice(0, 3).map(skill => (
                      <span key={skill} className="bg-slate-50 text-slate-500 px-2 py-1 rounded-lg text-[9px] font-black uppercase border border-slate-100">{skill}</span>
                    ))}
                    <button onClick={() => toggleExpand(lead.id)} className="text-[9px] font-black text-indigo-600 uppercase">
                      {expandedLeads[lead.id] ? 'Show Less' : 'Read More'}
                    </button>
                  </div>

                  {/* Deep Intel Section */}
                  <div className="bg-indigo-50/30 border border-indigo-100 rounded-2xl p-4 md:p-6 space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="text-[9px] font-black text-indigo-600 uppercase tracking-widest">Contact Intel</h4>
                      <button 
                        onClick={() => copyAllContactInfo(lead)}
                        className="text-[8px] font-black bg-indigo-600 text-white px-3 py-1.5 rounded-lg uppercase tracking-widest transition-all shadow-md shadow-indigo-100"
                      >
                        {copyStatus[lead.id + '-all-contact'] || 'Copy Details'}
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-4">
                      {lead.email && (
                        <a href={`mailto:${lead.email}`} className="flex items-center gap-2 text-xs font-bold text-slate-700 hover:text-indigo-600 truncate max-w-full">
                          <div className="w-8 h-8 rounded-xl bg-white flex items-center justify-center shadow-sm border border-slate-100 shrink-0">
                             <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                          </div>
                          <span className="truncate">{lead.email}</span>
                        </a>
                      )}
                    </div>
                  </div>

                  {/* Real-time Market News Display */}
                  {hasNews && (
                    <div className="mt-4 p-5 bg-slate-900 rounded-[1.5rem] border border-slate-800 text-white animate-in slide-in-from-top-4 duration-500">
                       <div className="flex items-center justify-between mb-4">
                          <h5 className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-400">Live Market Brief</h5>
                          <button onClick={() => setNewsData(prev => { const d = {...prev}; delete d[lead.id]; return d; })} className="text-slate-500 hover:text-white transition-colors">
                             <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" /></svg>
                          </button>
                       </div>
                       <div className="text-xs font-medium text-slate-300 leading-relaxed space-y-2 whitespace-pre-wrap">
                          <MarkdownRenderer content={newsData[lead.id].text} />
                       </div>
                       {newsData[lead.id].links.length > 0 && (
                         <div className="mt-4 pt-4 border-t border-slate-800 flex flex-wrap gap-2">
                            <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest w-full mb-1">Sources:</span>
                            {newsData[lead.id].links.map((link, idx) => (
                               <a key={idx} href={link.uri} target="_blank" className="bg-slate-800 hover:bg-slate-700 text-indigo-400 px-2.5 py-1 rounded text-[8px] font-bold border border-slate-700 transition-colors">
                                  {link.title}
                               </a>
                            ))}
                         </div>
                       )}
                    </div>
                  )}
                </div>

                {/* AI Console Area */}
                <div className="w-full xl:w-80 shrink-0 flex flex-col gap-4">
                  <div className={`bg-slate-50 border rounded-3xl p-5 space-y-5 transition-all duration-500 ${isHighlighted ? 'border-indigo-600 ring-4 ring-indigo-500/10 shadow-2xl scale-[1.02]' : 'border-slate-100'}`}>
                    <div className="flex items-center gap-4">
                       <div className="relative w-12 h-12 flex items-center justify-center shrink-0">
                          <svg className="w-full h-full transform -rotate-90">
                            <circle cx="24" cy="24" r="20" stroke="currentColor" strokeWidth="4" fill="transparent" className="text-slate-200" />
                            <circle cx="24" cy="24" r="20" stroke="currentColor" strokeWidth="4" fill="transparent" strokeDasharray={126} strokeDashoffset={126 - (126 * lead.matchScore) / 100} className="text-indigo-600" />
                          </svg>
                          <span className="absolute text-[10px] font-black text-slate-900">{lead.matchScore}%</span>
                       </div>
                       <div>
                         <h4 className="text-[9px] font-black text-indigo-600 uppercase tracking-widest">Match Strength</h4>
                         <p className="text-[10px] font-bold text-slate-500 leading-tight mt-1">{lead.matchReason}</p>
                       </div>
                    </div>

                    <div className="space-y-4">
                      <div className="flex bg-white p-1 rounded-xl border border-slate-200 shadow-sm no-scrollbar overflow-x-auto">
                        {['intel', 'proposal', 'step1', 'step2'].map(tab => (
                          <button
                            key={tab}
                            onClick={() => setActiveTab(prev => ({ ...prev, [lead.id]: tab as any }))}
                            className={`flex-1 px-2 py-2 rounded-lg text-[8px] font-black uppercase tracking-widest transition-all ${lActiveTab === tab ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400'}`}
                          >
                            {tab === 'intel' ? 'Intel' : tab === 'proposal' ? 'Prop' : tab === 'step1' ? 'Msg' : 'Seq'}
                          </button>
                        ))}
                      </div>

                      <div className="bg-white p-4 rounded-2xl border border-slate-200 min-h-[140px] max-h-[250px] overflow-y-auto relative">
                         <div className="flex justify-between items-center mb-2">
                            <span className="text-[7px] font-black uppercase"><span className="text-slate-900">lead</span><span className="text-indigo-600">live</span> {lActiveTab === 'proposal' ? 'Proposal' : 'Intel'}</span>
                            <button 
                              onClick={() => {
                                const texts: any = {
                                  intel: lead.competitorIntel,
                                  proposal: lead.proposalTemplate,
                                  step1: lead.outreachTemplate,
                                  step2: lead.followUpSequence?.step2,
                                };
                                handleCopy(lead.id, texts[lActiveTab]);
                              }}
                              className="text-[8px] font-black text-indigo-500"
                            >
                              {copyStatus[lead.id] || 'COPY'}
                            </button>
                         </div>
                         <div className="text-[10px] text-slate-600 font-medium leading-relaxed italic">
                           {lActiveTab === 'intel' && <MarkdownRenderer content={lead.competitorIntel || ''} />}
                           {lActiveTab === 'proposal' && <MarkdownRenderer content={lead.proposalTemplate || ''} />}
                           {lActiveTab === 'step1' && <MarkdownRenderer content={lead.outreachTemplate || ''} />}
                           {lActiveTab === 'step2' && <MarkdownRenderer content={lead.followUpSequence?.step2 || ''} />}
                         </div>
                      </div>
                    </div>

                    <div className="flex flex-col gap-2">
                      <button 
                        onClick={() => handleApplyWithAI(lead)}
                        className="w-full bg-indigo-600 text-white py-3 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
                      >
                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                        Apply with AI Proposal
                      </button>

                      <a href={lead.url} target="_blank" className="w-full bg-slate-900 text-white py-3 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-slate-800 transition-all">
                        Apply Direct
                      </a>
                      
                      <button
                        onClick={() => handleGetNews(lead)}
                        disabled={isFetching}
                        className={`w-full py-3 rounded-xl text-[10px] font-black uppercase tracking-widest border flex items-center justify-center gap-2 transition-all ${isFetching ? 'bg-slate-50 border-slate-200 text-slate-400' : 'bg-white border-indigo-200 text-indigo-600 hover:bg-indigo-50'}`}
                      >
                         {isFetching ? (
                            <>
                              <div className="w-3 h-3 border-2 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
                              Scanning...
                            </>
                         ) : (
                           <>
                             <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></div>
                             Market Intel
                           </>
                         )}
                      </button>

                      {hasConnectedCrm && onSyncCrm && (
                        <button
                          onClick={() => onSyncCrm(lead)}
                          disabled={lead.syncedToCrm}
                          className={`w-full py-3 rounded-xl text-[9px] font-black uppercase border transition-all ${
                            lead.syncedToCrm ? 'bg-emerald-50 border-emerald-100 text-emerald-600' : 'bg-white border-slate-200 text-slate-600'
                          }`}
                        >
                          {lead.syncedToCrm ? 'Synced' : 'Sync CRM'}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {!isSavedView && sortedLeads.length > 0 && onLoadMore && (
        <div className="pt-10 flex justify-center">
          <button 
            onClick={onLoadMore}
            disabled={isLoadingMore}
            className="bg-white border border-slate-200 text-slate-900 px-10 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-600 hover:text-white transition-all shadow-xl flex items-center gap-3"
          >
            {isLoadingMore ? 'Hunting...' : 'Scan More Leads'}
          </button>
        </div>
      )}
    </div>
  );
}
