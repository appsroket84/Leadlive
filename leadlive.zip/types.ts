
export enum Platform {
  UPWORK = 'Upwork',
  FIVERR = 'Fiverr',
  FREELANCER = 'Freelancer',
  LINKEDIN = 'LinkedIn',
  OTHER = 'Other'
}

export type LeadStatus = 'scouted' | 'applied' | 'interviewing' | 'won' | 'lost';
export type PlanType = 'free' | 'elite';
export type UserRole = 'owner' | 'member';

export interface TeamMember {
  id: string;
  fullName: string;
  email: string;
  role: UserRole;
  avatar?: string;
}

export interface Team {
  id: string;
  name: string;
  memberCount: number;
}

export interface Integration {
  id: string;
  name: string;
  type: 'email' | 'crm' | 'workflow';
  connected: boolean;
  icon: string;
  description: string;
  authUrl: string;
  color: string;
  isShared?: boolean;
}

export interface SocialLink {
  platform: string;
  url: string;
}

export interface Lead {
  id: string;
  title: string;
  company: string;
  description: string;
  platform: string;
  budget?: string;
  postedAt: string;
  url: string;
  mirrorSearchUrl: string;
  verificationReason?: string;
  verificationSnippet?: string;
  freshnessScore: number;
  tags: string[];
  clientRating?: number;
  clientReviewsCount?: number;
  duration?: string;
  durationWeeks?: number;
  skills?: string[];
  proposalTemplate?: string;
  outreachTemplate?: string;
  followUpSequence?: {
    step2: string;
    step3: string;
  };
  matchScore: number;
  matchReason: string;
  competitorIntel?: string;
  status: LeadStatus;
  lastContacted?: string;
  syncedToCrm?: boolean;
  email?: string;
  phone?: string;
  socialLinks?: SocialLink[];
  hiringContactName?: string;
  assignedTo?: string; // Member ID
}

export interface SearchParams {
  niche: string;
  location?: string;
  experienceLevel: string;
  budgetMin?: number;
  platforms: string[];
  jobType?: string;
  remoteOption?: string;
  keywords?: string;
  userEmail?: string;
  autoNotify?: boolean;
  notificationFrequency?: string;
  userBio?: string;
}

export type ViewType = 'scout' | 'saved' | 'settings' | 'home' | 'pipeline' | 'integrations' | 'billing' | 'team';

export interface UserProfile {
  fullName: string;
  email: string;
  phone: string;
  industry: string;
  niche: string;
  experienceLevel: string;
  bio: string;
  interests: string[];
  website?: string;
  hasCompletedOnboarding: boolean;
  plan: PlanType;
  scansRemaining: number;
  totalScansPerformed: number;
  lastScanReset?: string;
  teamId?: string;
  role?: UserRole;
  // Admin Config for PayPal (The App Owner's Info)
  paypalClientId?: string;
  paypalEmail?: string;
}
