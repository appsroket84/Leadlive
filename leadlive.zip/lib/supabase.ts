
import { createClient } from '@supabase/supabase-js';

// Credentials provided by the user for the 'livelead' project
const supabaseUrl = 'https://ztapachqskkwuoyytbjd.supabase.co';
const supabaseAnonKey = 'sb_publishable_Pw5z2arWoqSjeoHMti2RUg_h3L32cHi';

// Initialize the Supabase client
export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Helper to check if supabase is ready (always true now that we have keys)
export const isSupabaseConfigured = true;
